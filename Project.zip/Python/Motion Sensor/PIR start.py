import time
import RPi.GPIO as GPIO

GPIO.setmode(GPIO.BCM)

ledRed = 21
ledGreen = 1
ledBlue = 20
motionSensor = 26
buzzer = 12

GPIO.setmode(GPIO.BCM)

GPIO.setup(ledRed, GPIO.OUT)        #Red pin LED
GPIO.setup(ledGreen, GPIO.OUT)      #Green pin LED
GPIO.setup(ledBlue, GPIO.OUT)       #Blue pin LED
GPIO.setup(motionSensor, GPIO.IN)   #Motionsensor
GPIO.setup(buzzer, GPIO.OUT)        #Buzzer

def MotionDetected(motionSensor):
    print("Motion detected")
    print("Lights on, Buzzer activating")
    GPIO.output(ledRed, True)
    GPIO.OUTPUT(ledGreen, False)
    GPIO.output(ledBlue, False)
    GPIO.output(buzzer, True)
    time.sleep(5)
    GPIO.output(buzzer, False)


print("Motion Sensor Alarm")
time.sleep(.2)
print("ready")

try:
    time.sleep(2) # to stabilize sensor
    while True:
        if GPIO.input(motionSensor):
            MotionDetected(motionSensor)
            time.sleep(5) #to avoid multiple detection
        time.sleep(0.1) #loop delay, should be less than detection delay

except:
    GPIO.cleanup()