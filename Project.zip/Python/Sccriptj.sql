SELECT ID, DeviceStatus AS 'Aan / Uit', Temp_status AS 'Temperatuur', WL_status AS 'Waterlevel', Sound_status AS 'Sound',
Licht_status AS 'Licht', Locatie FROM tblsensorstatus