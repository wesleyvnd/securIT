SELECT MetingID, tbldata.DeviceID, Temperatuur, Licht, Sound, Waterlevel, " \
          "CONCAT(InputDate, ' ', InputTime) AS 'DateTime', tblsensorstatus.DeviceStatus, tblsensorstatus.Temp_status, " \
          "tblsensorstatus.WL_status, tblsensorstatus.Sound_status, tblsensorstatus.Licht_status from tbldata INNER JOIN tblsensorstatus where tbldata.DeviceID = tblsensorstatus.DeviceID