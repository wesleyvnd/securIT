function init(){
	// create child
    var p = document.createElement("p");
	// child een ID toewijzen zodat je die later kan aanspreken (kan ook met klasse)
    p.id = 'p';
	// voorbeeld van appenden in een tag txtDel komt in P te zitten (p wordt parent van txtDel MAAR p is child van Div later)
    var txtDel = document.createTextNode("This needs to be deleted");
    p.appendChild(txtDel);

	// parent tag aanspreken om P erin te steken
    var div = document.querySelector('.c-nav');
    div.appendChild(p);
	
	//HTML is opgebouwd
}
document.addEventListener('DOMContentLoaded', function() {
    console.info('DOM geladen');
    init();
	// Element die de event doet afgaan aanspreken & eventlistener op zetten
    button = document.querySelector('#button');
    button.addEventListener('click', function(){
		// parent EN child aanspreken op onderstaande manier (of elementById idc)
        var div = document.querySelector('.c-nav');
        var p = document.querySelector('#p')

        // P (child) wordt dan verwijderd uit zijn parent DIV (parent)
		// werkt niet omgekeerd (p.removeChild(div)) omdat p child is van DIV en niet omgekeerd = error
        div.removeChild(p)
    })
});