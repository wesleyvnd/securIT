const addContent = function(jsonObject){
    var HTML = "";
    let values =  Object.values(jsonObject)
    for(let i=0; i<jsonObject.length; i++){
        HTML += "<form action='' class='content' method='POST' id='frm"+ jsonObject[i]['Locatie'] +"'>";
        // <a href="Room.html?id=${items[i-1]}">${items[i]}</a>
            HTML += "<h2><a href='Room.html?id=" + jsonObject[i]['ID'] + "'>"+ jsonObject[i]['Locatie'] +"</a></h2>";
            HTML += addSensorStatus(jsonObject[i]);
            if(jsonObject[i]['Device'] == 1){
                HTML += "<input type='submit' class='sensorAan' id='btnAan' value='AAN'/>"
            } else {
                HTML += "<input type='submit' class='sensorUit' id='btnUit' value='UIT'/>"
                //  form='frm"+ jsonObject[i]['Locatie'] +"'  voor frm'Locatie' als submit in te stellen
            }
        HTML += "</form>"; /*CLOSES CONTENT DIV*/ 
    }
    return HTML;
}
const addSensorStatus = function(jsonObject){
    let HTML = "<ul>";
    let values =  Object.values(jsonObject)
    let keys = Object.keys(jsonObject)
    for(let i=3; i<7; i++){
        if(values[i] == 0){
            HTML += "<li id='"+ keys[i].substring(0,5) + "'>"+ keys[i] + ": <span class='uit' id='subSensor"+(i-2)+"Uit'></span></li>";
        } else {
            HTML += "<li id='"+ keys[i].substring(0,5) + "'>"+ keys[i] + ": <span class='aan' id='subSensor"+(i-2)+"Aan'></span></li>";
        }
    }
    HTML += "</ul>";
    return HTML;
}
const maakKolom = function(jsonObject){
    var HTML =  "<h1>Dashboard</h1><div class='kolom'>";
    HTML += addContent(jsonObject);
    HTML += "</div>";
    return HTML;
}
const toonData = function(jsonObject, cssSelector){
    document.querySelector(cssSelector).innerHTML = maakKolom(jsonObject);
}
function init(){
    console.info("Data ophalen")
    handleData('http://127.0.0.1:5000/api/v1/dashboard', toonData, '.component');    
}
document.addEventListener('DOMContentLoaded', function() {
    console.info('DOM geladen');
    init();
    

  document.addEventListener('click',function(e){
    const addForm = document.querySelector('#frmAdd');
    addForm.addEventListener('submit', function(e){
        e.preventDefault();
        data = toJSONString(this)
        console.log(data);
        this.submit();
    });

    if(e.target && e.target.id== 'btnAan'){
        console.info('aan');
     } else if (e.target && e.target.id == 'btnUit'){
            
     } else if(e.target && e.target.id == 'subSensor1Aan'){
        console.info('small green klik on');
     } else if(e.target && e.target.id == 'subSensor1Uit'){
        console.info('small green klik off');
     }
 });
});
