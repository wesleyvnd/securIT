const maakTabelTitels = function(headers) {
  let HTML = '<thead><tr>';
  for(var i=1; i<7; i++){
    HTML += `<th>${headers[i]}</th>`;
  }

  HTML += '</thead></tr>';
  return HTML;
};

const maakTabelRij = function(items, id) {
  let HTML = '<tr>';
  for (var i=1; i<7; i++) {
      if(items[i] == 0){
           HTML += `<td>Uit</td>`;
       } else if(items[i] == 1){
           HTML += `<td>Aan</td>`;
       } else {
           HTML += `<td><a href="Room.html?id=${items[i-1]}">${items[i]}</a></td>`;
       }
  }
  HTML += '</tr>';
  return HTML;
};

const maakTabel = function(jsonObject, ID, Titel) {
  let HTML = Titel + '<table>';
  HTML += maakTabelTitels(Object.keys(jsonObject[0]));
  HTML += '<tbody>';
  for (const i in jsonObject) {
    const id = jsonObject[i][ID];
    HTML += maakTabelRij(Object.values(jsonObject[i]), id);
  }
  HTML += '</tbody></table>';
  return HTML;
};



const toonData = function(jsonObject, cssSelector) {
  document.querySelector(cssSelector).innerHTML = maakTabel(jsonObject, '.component', '<h2>Overview Sensoren</h2>');
  console.info(jsonObject)
};

function init(){
    console.info("Data ophalen")
    handleData('http://127.0.0.1:5000/api/v1/data_json', toonData, '.component');
}

document.addEventListener('DOMContentLoaded', function() {
  console.info('DOM geladen');
  init();
});
