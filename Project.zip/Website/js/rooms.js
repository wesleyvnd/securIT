'use strict';
const maakTabelTitels = function(headers) {
    let HTML = '<tr>';
    for (const header of headers) {
      HTML += `<th>${header}</th>`;
    }

    HTML += '<tr>';
    return HTML;
};

const maakTabelRij = function(items, id) {
    let HTML = '<tr>';
    let i=1;
    for (const item of items) {
      if(i==1){
        HTML += `<td>`+ 'Nr. ' +`${item}</td>`;
      } else if(i==2){
        HTML += `<td>${item}°</td>`;
      } else if(i==3){
        HTML += `<td>${item} cd</td>`;
      } else if(i==4){
        HTML += `<td>${item} dB</td>`;
      } else if(i==5){
        HTML += `<td>${item} %</td>`;
      } else if(i==6){
        HTML += `<td>${item}</td>`;
      }
      i++;
    }
    HTML += '</tr>';
    return HTML;
};

const maakTabel = function(jsonObject, ID, Titel) {
  let HTML = Titel + '<table>';
  HTML += maakTabelTitels(Object.keys(jsonObject[0]));
  HTML += '<tbody>';
  for (const i in jsonObject) {
    const id = jsonObject[i][ID];
    HTML += maakTabelRij(Object.values(jsonObject[i]), id);
  }
  HTML += '</tbody></table>';
  return HTML;
};


const toonData = function(jsonObject, cssSelector) {
  document.querySelector(cssSelector).innerHTML = maakTabel(jsonObject, '.component', '<h2>Slaapkamer</h2>');
};

const init = function() {
  console.info('Toont Data');
  const param = window.location.search.split('=')[1];
  var test = handleData('http://127.0.0.1:5000/api/v1/sensor/' + param, toonData, '.component');
  if(test == null || test == undefined){
      document.querySelector('.component').innerHTML = "<h2>Geen data gevonden</h2>";
  }
};

document.addEventListener('DOMContentLoaded', function() {
  console.info('DOM geladen');
  init();
});
