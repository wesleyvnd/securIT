from flask import Flask, jsonify, request
from DP1.Database import Database
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

# Custom endpoint
endpoint = '/api/v1'
conn = Database(app=app, user='root', password='Admin123', db='projectdb', host='localhost', port=3306)

# # ROUTES
@app.route(endpoint + '/data_json')
def data_json():
    sql = "SELECT ID, Locatie, DeviceStatus AS 'Status', Temp_status AS Temperatuur, WL_status AS 'Waterlevel', Sound_status AS 'Sound', Licht_status AS 'Licht'  FROM tblsensorstatus"
    data = conn.get_data(sql)
    return jsonify(data)


@app.route(endpoint + '/sensor/<id>', methods=['GET', 'POST'])
def locatie(id):
    if(request.method == 'GET'):
        sql = "Select MetingID AS 'Meting #', Temperatuur, Licht, Sound, Waterlevel, InputDateTime AS 'Datetime' from tbldata where DeviceID = '"+id+"'"
        data = conn.get_data(sql)
        return jsonify(data)

@app.route(endpoint + '/dashboard', methods=['GET','POST', 'PUT', 'DELETE'])
def dashboard():
    if (request.method == 'GET'):
        sql = "SELECT ID, Locatie, DeviceStatus AS 'Device', Temp_status AS 'Temperatuur sensor', WL_status AS 'Water level sensor', Sound_status AS 'Geluid sensor', Licht_status AS 'Licht sensor' FROM tblsensorstatus"
        data = conn.get_data(sql)
        return jsonify(data)

    if (request.method == 'POST'):
        data = request.form
        plaats = request.form['sensorPlaats']
        motion = data['motionsensor']
        water = request.form['waterlevelsensor']
        geluid = request.form['geluidsensor']
        licht = request.form['lichtsensor']
        formattedData = [motion, water, geluid, licht]
        for i in range(0, len(formattedData)):
            if(formattedData[i] == 'on'):
                formattedData[i]  = '1'
            else:
                formattedData[i]  = 0
        sql = "INSERT INTO tblsensorstatus (Locatie, DeviceStatus, Motion_status, WL_status, Sound_status, Licht_status) ' \
              'VALUES()"
        conn.set_data(sql)
        print("plaats: {}, motion: {}, water: {}, geluid: {}, licht: {}".format(plaats, formattedData[0], formattedData[1], formattedData[2], formattedData[3]))
        return jsonify(data)

@app.after_request
def add_headers(response):
    response.headers.add('Access-Control-Allow-Origin', '*')
    response.headers.add('Access-Control-Allow-Headers', 'Content-Type,Authorization')
    return response
if __name__ == '__main__':
    app.config['JSON_SORT_KEYS'] = False
    app.run(debug=True)
