-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema mydb
-- -----------------------------------------------------
-- -----------------------------------------------------
-- Schema projectdb
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema projectdb
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `projectdb` DEFAULT CHARACTER SET utf8 ;
USE `projectdb`;

-- -----------------------------------------------------
-- Table `projectdb`.`tblsensorstatus`
-- -----------------------------------------------------

CREATE TABLE IF NOT EXISTS `projectdb`.`tblsensorstatus` (
  `ID` INT(11) NOT NULL AUTO_INCREMENT,
  `Locatie` VARCHAR(45) NOT NULL,
  `DeviceStatus` VARCHAR(45) NOT NULL,
  `Motion_status` VARCHAR(45) NOT NULL,
  `WL_status` VARCHAR(45) NOT NULL,
  `Sound_status` VARCHAR(45) NOT NULL,
  `Licht_status` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`ID`))
ENGINE = InnoDB
AUTO_INCREMENT = 4
DEFAULT CHARACTER SET = utf8
COMMENT = 'Motion = Motion sensor, WL = water level sensor, sound = sound sensor, licht = lichtsensor';


-- -----------------------------------------------------
-- Table `projectdb`.`tbldata`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `projectdb`.`tbldata` (
  `MetingID` INT(11) NOT NULL AUTO_INCREMENT,
  `DeviceID` INT(11) NOT NULL,
  `Motion` INT(11) NULL DEFAULT NULL,
  `Licht` INT(11) NULL DEFAULT NULL,
  `Sound` INT(11) NULL DEFAULT NULL,
  `Waterlevel` INT(11) NULL DEFAULT NULL,
  `InputDateTime` DATETIME NULL DEFAULT NULL,
  PRIMARY KEY (`MetingID`),
  INDEX `DeviceID_idx` (`DeviceID` ASC),
  CONSTRAINT `DeviceID`
    FOREIGN KEY (`DeviceID`)
    REFERENCES `projectdb`.`tblsensorstatus` (`ID`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB
AUTO_INCREMENT = 4
DEFAULT CHARACTER SET = utf8;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
